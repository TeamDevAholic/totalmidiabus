<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class permissions_roles extends Model
{
    //
}
